from zipfile import ZipFile
from pathlib import Path
path = Path("/home/junaid/Desktop/PYTHON3/working_with_files")
# zip = ZipFile("zipfile.zip", "w")
with ZipFile("ZipFile.zip", "w") as zip:
    for path in path.rglob("*.*"):
        zip.write(path)

# print(path)

# print(path.exists())
# path = [p for p in path.iterdir()]
# print(path)
